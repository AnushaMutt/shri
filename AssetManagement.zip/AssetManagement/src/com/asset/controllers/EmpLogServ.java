package com.asset.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.asset.dto.Employee;
import com.asset.service.ServiceClass;

@WebServlet("/log")
public class EmpLogServ extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int empid = Integer.parseInt(req.getParameter("empid"));
		String password = req.getParameter("pass");
		
		
		ServiceClass Services = new ServiceClass();
		
		Employee e = Services.loginE(empid,password);
		System.out.println(e);
		
		if(e!=null)
		{
			
				System.out.println("Login Sucessfull");
				resp.sendRedirect("./emp.html");

			
		}else {
			//Login Failed
			System.out.println("Login Failed");
			resp.sendRedirect("./Login.html");
		}
		
	}


}
