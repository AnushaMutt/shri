package com.asset.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.asset.service.ServiceClass;


@WebServlet("/deleteemp")
public class DeleteEmpServ extends HttpServlet {
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		
		int  empid = Integer.parseInt(req.getParameter("empId"));
		
		ServiceClass service = new ServiceClass();
		
		
		boolean b = service.delete(empid);
		
		if(b)
		{
			HttpSession session=req.getSession();
			System.out.println("Employee deleted");
			//resp.sendRedirect("./DeleteEmp1.html");
			
			
		}
		else
		{
			System.out.println("failed");
			//resp.sendRedirect("./DeleteEmp.html");
			
			
		}
	}
	
	

}
