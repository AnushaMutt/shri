package com.asset.controllers;

import java.io.IOException;


import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.asset.dto.Asset;
import com.asset.service.ServiceClass;


@WebServlet("/list1")
public class UnallocServ extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		ServiceClass service = new ServiceClass();
		
		List<Asset> list = service.getUnalloc();
		
		
	}

}
