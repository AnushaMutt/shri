package com.asset.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.asset.dto.User;
import com.asset.service.ServiceClass;

@WebServlet("/create")
public class CreateServ extends HttpServlet {
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	

		int  userId = Integer.parseInt(req.getParameter("userId"));
		String userName = req.getParameter("userName");
		String password = req.getParameter("password");
		
		
		ServiceClass sc = new ServiceClass();
		
		User user= new User();
		
		user.setUserId(userId);
		user.setUserName(userName);
		user.setPassword(password);
		
		
		
		boolean b= sc.create(user);
		
		if(b)
		{
			System.out.println("Profile created");
			//resp.sendRedirect("./Addre.html");


		}
		else
		{
			System.out.println("create failed");
			//resp.sendRedirect("./AddAsset.html");


		}

		
		
		
	}

}
