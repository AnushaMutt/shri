 package com.asset.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.asset.dto.User;
import com.asset.service.ServiceClass;

@WebServlet("/login")
public class LoginServ extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("uname");
		String password = req.getParameter("pass");
		
		ServiceClass Services = new ServiceClass();
		User u = Services.login(username,password);
		System.out.println(u);
		
		if(u!=null)
		{
			
				
			
				System.out.println("Login Sucessfull");
				resp.sendRedirect("./AdminPage.html");
			
			
		}else {
			//Login Failed
			System.out.println("Login Failed");
			resp.sendRedirect("./Login.html");
		}
		
	}

	
}
