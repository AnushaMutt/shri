package com.asset.dto;

public class Request {
	
	private  int allocationId;
	private int assetId;
	private int empNo;
	private String status;
	
	
	public int getAllocationId() {
		return allocationId;
	}
	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Request [allocationId=" + allocationId + ", assetId=" + assetId + ", empNo=" + empNo + ", status="
				+ status + ", getAllocationId()=" + getAllocationId() + ", getAssetId()=" + getAssetId()
				+ ", getEmpNo()=" + getEmpNo() + ", getStatus()=" + getStatus() + "]";
	}
	
	

}
