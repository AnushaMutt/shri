package com.asset.dto;

public class Employee {
	
	private int empId;
	private String empName;
	private String password;
	private String job;
	private String dept;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", password=" + password + ", job=" + job
				+ ", dept=" + dept + ", getEmpId()=" + getEmpId() + ", getEmpName()=" + getEmpName()
				+ ", getPassword()=" + getPassword() + ", getJob()=" + getJob() + ", getDept()=" + getDept() + "]";
	}
	
	
	
	

}


