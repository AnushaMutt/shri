package com.asset.dto;

public class Asset {
	
	private int assetId;
	private String assetName;
	
	private int assetQty;
	private String assetStatus;
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public int getAssetQty() {
		return assetQty;
	}
	public void setAssetQty(int assetQty) {
		this.assetQty = assetQty;
	}
	public String getAssetStatus() {
		return assetStatus;
	}
	public void setAssetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}
	@Override
	public String toString() {
		return "Asset [assetId=" + assetId + ", assetName=" + assetName + ", assetQty=" + assetQty + ", assetStatus="
				+ assetStatus + ", getAssetId()=" + getAssetId() + ", getAssetName()=" + getAssetName()
				+ ", getAssetQty()=" + getAssetQty() + ", getAssetStatus()=" + getAssetStatus() + "]";
	}
	
	

}
