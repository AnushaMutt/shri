package com.asset.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.asset.dto.Asset;
import com.asset.service.ServiceClass;


@WebServlet("/add1")

public class AddAssetServ extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {



		int  assetId = Integer.parseInt(req.getParameter("assetId"));
		String assetName = req.getParameter("assetName");
		
		int  assetQty = Integer.parseInt(req.getParameter("assetQty"));
		String assetStatus = req.getParameter("assetStatus");


		ServiceClass service = new ServiceClass();

		Asset asset = new Asset();
		

		asset.setAssetId(assetId);
		asset.setAssetName(assetName);
		
		asset.setAssetQty(assetQty);
		asset.setAssetStatus(assetStatus);

		boolean b = service.add(asset);

		if(b)
		{
		
			System.out.println("Profile created");
			resp.sendRedirect("./Addre.html");


		}
		else
		{
			System.out.println("Adding failed");
			resp.sendRedirect("./AddAsset.html");


		}

	}

}
