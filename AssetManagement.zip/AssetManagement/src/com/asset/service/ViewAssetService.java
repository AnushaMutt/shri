package com.asset.service;


import java.util.List;

import com.asset.dao.ViewAssetDAO;
import com.asset.dao.ViewAssetImpl;
import com.asset.dto.Request;


public class ViewAssetService {

	public static List<Request> fetchAllocatedAsset(){

		ViewAssetDAO dao=new ViewAssetImpl();

		List<Request> las=dao.fetchAllocatedAsset();

		return las;
	}

	public static List<Request> fetchUnallocatedAsset(){

		ViewAssetDAO dao=new ViewAssetImpl();

		List<Request> las=dao.fetchUnallocatedAsset();

		return las;
	}
}
