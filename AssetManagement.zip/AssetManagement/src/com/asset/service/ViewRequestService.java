package com.asset.service;

import java.util.List;

import com.asset.dto.Asset;



public class ViewRequestService {
	
	public static List<Asset> fetchRequest(){
		 
		ViewRequestService vs=new ViewRequestService();
		
		List<Asset> las=vs.fetchRequest();
		
		return las;
	}

}
