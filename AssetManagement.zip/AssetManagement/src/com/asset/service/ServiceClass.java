package com.asset.service;


import java.util.List;

import com.asset.dao.AssetDao;


import com.asset.dao.AssetDaoImp;
import com.asset.dao.EmpDao;
import com.asset.dao.EmpdaoImp;
import com.asset.dao.UserDao;

import com.asset.dao.UserdaoImp;
import com.asset.dto.Asset;
import com.asset.dto.Employee;
import com.asset.dto.User;

public class ServiceClass {
	
	
	public boolean create(User user) {

		UserDao dao = new UserdaoImp();

		boolean b = dao.createUser(user);

		return b;

	}
	
	
	public User login(String username, String password) {
		UserDao dao = new UserdaoImp();

		User u = dao.login(username,password);

		return u;
	}
	
	
	public boolean add(Employee emp){
		
		EmpDao dao1 = new EmpdaoImp();

		boolean b = dao1.addEmp(emp);

		return b;
		
		
	}


	public boolean delete(int empid) {
		EmpDao dao1 = new EmpdaoImp();

		boolean b = dao1.delEmp(empid);

		return b;
		
	}



	public Employee loginE(int empid, String password) {
		
		EmpDao dao1 = new EmpdaoImp();

		Employee e = dao1.loginE(empid,password);

		return e;
	}


	public boolean add(Asset asset) {
		AssetDao dao = new AssetDaoImp();

		boolean a = dao.addAsset(asset);

		return a;
	}


	public boolean request(int allocationId, int assetId, int empNo) {
		
		AssetDao dao = new AssetDaoImp();

		boolean b =dao.requestAsset(allocationId,assetId,empNo );
		return b;
	}


	public boolean allocate(int allocationId) {
		
		AssetDao dao = new AssetDaoImp();

		boolean b=dao.allocateRequest(allocationId);
		return b;
	}


	public List<Asset> getAlloc() {
		AssetDao dao = new AssetDaoImp();

		List<Asset> list = dao.getAllocated();

		return list;

	}


	public List<Asset> getUnalloc() {

		AssetDao dao = new AssetDaoImp();

		List<Asset> list = dao.getUnallocated();

		return list;


	}


	

}
