package com.asset.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.asset.dto.Asset;
import com.asset.dto.Request;

public class AssetDaoImp implements AssetDao {

	@Override
	public boolean addAsset(Asset asset) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String userName = "root";
        String password = "marlabs";

		try
		{
			

			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,password);
           

			System.out.println("connected");
			String query = "insert into asset values(?,?,?,?)";
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, asset.getAssetId());
			pstmt.setString(2, asset.getAssetName());
			pstmt.setInt(3, asset.getAssetQty());
			pstmt.setString(4, asset.getAssetStatus());


			System.out.println("added");
			int count = pstmt.executeUpdate();

			if(count>0)
			{
				return true;
			}
			else
			{
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}
		return false;
	}

	@Override
	public boolean requestAsset(int allocationId, int assetId, int empNo) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String userName = "root";
        String password = "marlabs";

		try
		{
			

			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,password);
           

			System.out.println("connected");

			String query = "insert into  request values(?,?,?,?)";
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, allocationId);
			pstmt.setInt(2, assetId);
			pstmt.setInt(3, empNo);
			pstmt.setString(4, "unallocated");




			System.out.println("added");
			int count = pstmt.executeUpdate();

			if(count>0)
			{
				System.out.println("requested");
			}
			else
			{
				System.out.println("failed");
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}
		return false;
	}

	@Override
	public boolean allocateRequest(int allocationId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String userName = "root";
        String password = "marlabs";

		try
		{
			

			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,password);
           

			System.out.println("connected");
			String query = "Update request set status = 'allocated' where allocation_id = ? ";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, allocationId);


			int count = pstmt.executeUpdate();

			if(count>0)
			{

				System.out.println("allocated");
			}


		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
			if(pstmt!=null)
			{
				try {
					pstmt.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		}



		return false;
	}

	@Override
	public List<Asset> getAllocated() {
		List<Asset> list = new ArrayList<Asset>();


		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String userName = "root";
        String password = "marlabs";

		try
		{
			

			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,password);
           

			System.out.println("connected");

			String query = "select * from request where status='allocated'";
			stmt = con.createStatement();



			rs = stmt.executeQuery(query);

			while(rs.next())
			{
				Request r = new Request();
				
			

				r.setAllocationId(rs.getInt(1));
				r.setAssetId(rs.getInt(2));
				r.setEmpNo(rs.getInt(3));
				r.setStatus(rs.getString(4));


				System.out.println(r.getAllocationId());
				System.out.println(r.getAssetId());
				System.out.println(r.getEmpNo());
				System.out.println(r.getStatus());


			}



		}


		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
			if(stmt!=null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}



		return list;
	}

	@Override
	public List<Asset> getUnallocated() {
		List<Asset> list = new ArrayList<Asset>();


		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String userName = "root";
        String password = "marlabs";

		try
		{
			

			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,password);
           

			System.out.println("connected");

			String query = "select * from request where status='unallocated'";
			stmt = con.createStatement();



			rs = stmt.executeQuery(query);

			while(rs.next())
			{
				Request r = new Request();

				r.setAllocationId(rs.getInt(1));
				r.setAssetId(rs.getInt(2));
				r.setEmpNo(rs.getInt(3));
				r.setStatus(rs.getString(4));


				System.out.println(r.getAllocationId());
				System.out.println(r.getAssetId());
				System.out.println(r.getEmpNo());
				System.out.println(r.getStatus());


			}



		}


		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
			if(stmt!=null)
			{
				try {
					stmt.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}







		return list;
	}

}
