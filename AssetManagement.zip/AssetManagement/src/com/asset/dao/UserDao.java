package com.asset.dao;

import com.asset.dto.User;

public interface UserDao {
	
	

	public boolean createUser(User user);
	
	public User login(String username, String password); 



}
