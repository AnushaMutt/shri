package com.asset.dao;

import java.util.List;

import com.asset.dto.Request;


public interface ViewAssetDAO {
	
	public List<Request> fetchAllocatedAsset();
	
	public List<Request> fetchUnallocatedAsset();
}
