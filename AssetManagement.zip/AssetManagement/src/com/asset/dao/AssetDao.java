package com.asset.dao;

import java.util.List;

import com.asset.dto.Asset;

public interface AssetDao {

	boolean addAsset(Asset asset);

	boolean requestAsset(int allocationId, int assetId, int empNo);

	boolean allocateRequest(int allocationId);

	List<Asset> getAllocated();

	List<Asset> getUnallocated();

}
 