package com.asset.dao;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.asset.dto.Request;


public class ViewAssetImpl implements ViewAssetDAO{

	@Override
	public List<Request> fetchAllocatedAsset() {

		List<Request> lst=new ArrayList<Request>();
		ResultSet rs=null;
		Statement stmt=null;
		
		
		Connection con = null;
		PreparedStatement pstmt = null;
		String userName = "root";
        String password = "marlabs";

		try
		{
			

			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,password);
           

			stmt=con.createStatement();
			String query="select * from request where status='allocated'";
			rs=stmt.executeQuery(query);


			while(rs.next()) 
			{    
				Request r = new Request();
				r.setAllocationId(rs.getInt("allocation_id"));
				r.setAssetId(rs.getInt("asset_id"));
				r.setEmpNo(rs.getInt("emp_no"));
				r.setStatus(rs.getString("status"));

				lst.add(r);
			}

		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) 
			{
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt!=null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(rs!=null) 
			{
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return lst;
	}

	@Override
	public List<Request> fetchUnallocatedAsset() {
		
		ResultSet rs=null;
		List<Request> lst=new ArrayList<Request>();

		Connection con = null;
		Statement stmt = null;
		String userName = "root";
        String password = "marlabs";

		try
		{
			

			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,password);
           
			stmt=con.createStatement();
			String query="select * from request where status='unallocated'";
			rs=stmt.executeQuery(query);


			while(rs.next()) 
			{   
				
				Request r = new Request();
				r.setAllocationId(rs.getInt("allocation_id"));
				r.setAssetId(rs.getInt("asset_id"));
				r.setEmpNo(rs.getInt("emp_no"));
				r.setStatus(rs.getString("status"));

				lst.add(r);

			}

		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) 
			{
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt!=null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(rs!=null) 
			{
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return lst;
	}


}
