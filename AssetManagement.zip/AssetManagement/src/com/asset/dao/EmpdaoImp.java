package com.asset.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.asset.dto.Employee;
import com.asset.dto.User;

public class EmpdaoImp implements EmpDao {

	@Override
	public boolean addEmp(Employee emp) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String userName = "root";
        String password = "marlabs";

		try
		{
			

			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,password);
           

			System.out.println("connected");

			String query = "insert into employee values(?,?,?,?,?)";
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1,emp.getEmpId());
			pstmt.setString(2, emp.getEmpName());
			pstmt.setString(3, emp.getPassword());
			pstmt.setString(4, emp.getJob());
			pstmt.setString(5, emp.getDept());
			
			

			System.out.println("added");
			int count = pstmt.executeUpdate();

			if(count>0)
			{
				return true;
			}
			else
			{
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}


	return false;
	}

	@Override
	public boolean delEmp(int empid) {
		Connection con = null;
		PreparedStatement pstmt = null;

		try
		{

			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/project?user=root&password=marlabs";
			con = DriverManager.getConnection(url);

			System.out.println("connected");

			String query = "Delete from employee where emp_id = ?";
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, empid);



			System.out.println("deleted");
			int count = pstmt.executeUpdate();

			if(count>0)
			{
				return true;
			}
			else
			{
				return false;
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		}


		return true;
	}

	@Override
	public Employee loginE(int empid, String password) {
		String userName = "root";
        String Password = "marlabs";

		Connection con = null;
		PreparedStatement pstmt = null;
		
	
		ResultSet rs = null;

		String sql = "select * from employee where emp_id= ? and emp_password=?";
		Employee e = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,Password);
         
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, empid);
			pstmt.setString(2, password);
			
			rs = pstmt.executeQuery();
			System.out.println(rs);

			if(rs.next()) {
				e=new Employee();

				e.setEmpId(rs.getInt("emp_id"));
				e.setPassword(rs.getString("emp_password"));
				
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}finally {
			if(con != null) {
				try {
					con.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		}
		return e;
		
	}

}
