package com.asset.dao;

import com.asset.dto.Employee;

public interface EmpDao {

	
	public boolean addEmp(Employee emp);

	public boolean delEmp(int empid);

	public Employee loginE(int empid, String password);
}
