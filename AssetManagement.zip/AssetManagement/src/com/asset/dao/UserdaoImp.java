package com.asset.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.asset.dto.User;

public class UserdaoImp implements UserDao {

	@Override
	public boolean createUser(User user) {
		
		
	
			
			Connection con = null;
			PreparedStatement pstmt = null;
			String userName = "root";
	        String password = "marlabs";

			try
			{
				

				Class.forName("com.mysql.jdbc.Driver");
	            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,password);
	           // statement = connect.createStatement();
				
				
				//Class.forName("com.mysql.jdbc.Driver");
				//String url = "jdbc:mysql://localhost:3306/project?user=root&password=marlabs";
				//con = DriverManager.getConnection(url);

				System.out.println("connected");

				String query = "insert into user values(?,?,?)";
				pstmt = con.prepareStatement(query);

				pstmt.setInt(1, user.getUserId());
				pstmt.setString(2, user.getUserName());
				pstmt.setString(3, user.getPassword());
				

				System.out.println("added");
				int count = pstmt.executeUpdate();

				if(count>0)
				{
					return true;
				}
				else
				{
					return false;
				}

			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				if(con!=null)
				{
					try {
						con.close();
					} catch (SQLException e) {

						e.printStackTrace();
					}
				}
			}


		return false;
	}

	@Override
	public User login(String username, String password) {
		
		String userName = "root";
        String Password = "marlabs";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "select * from user where user_name= ? and password=?";
		User u = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/project", userName,Password);
         
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			
			rs = pstmt.executeQuery();
			System.out.println(rs);

			if(rs.next()) {
				u=new User();

				u.setUserName(rs.getString("user_name"));
				u.setPassword(rs.getString("password"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return u;
		
		
	}

	
	

}
